let a=3;
let b=5;
console.log("The Sum of two no is ",(a+b));
console.log("The Sub of two no is ",(a-b));
console.log("The Mul of two no is ",(a*b));
console.log("The Div of two no is ",(a/b));
console.log("The Mod of two no is ",(a%b));