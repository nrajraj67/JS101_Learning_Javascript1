let a= 4;
let b = 5;
console.log(a**5);
let x=49;
console.log(x**0.5);
console.log(x**(1/2));