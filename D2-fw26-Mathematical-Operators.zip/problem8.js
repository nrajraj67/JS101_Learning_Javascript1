let age=22;
let name="Nikhil";
console.log("My name is "+name+" and age is "+age);
console.log(typeof(name+age));