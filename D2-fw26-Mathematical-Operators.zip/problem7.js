let a="Nikhil";
let b="Raj";
console.log("My name is",":", ,a+b);
console.log(typeof(a+b));
