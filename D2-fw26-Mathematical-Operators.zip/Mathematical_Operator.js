//1.
let Name ="Nikhil Raj";
console.log("My name is ",Name);

//2.
let $123= "masai";
let $Nikh= "School";
let _123="Bengaluru";
console.log($123);
console.log($Nikh);
console.log(_123);