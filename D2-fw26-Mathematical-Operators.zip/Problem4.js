let a=99;
let b=8;
console.log(a%b);
let c= 55;
let d=3;
console.log(c%d);
let x=0;
let y=0;
console.log(x%y);
